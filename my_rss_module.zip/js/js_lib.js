function rssChannelCreateAndSelect(channels, curChannel, rssPath){
	channelsObj = jQuery.parseJSON(channels);
	jQuery('.my_rss_container select[name=channel]').each(function(){
		var n = 0, index;
		for(channel in channelsObj){
			jQuery('<option />', {
				'value': channel,
				'text': channelsObj[channel][0]
			}).appendTo(jQuery(this));
			if(channel == curChannel){
				index = n;
			}
			n++;
		}
		this.selectedIndex = index;
		jQuery(this).on('change', function(){
			window.location.assign(rssPath + '?channel=' + jQuery(this).val()); 
		});
	});
}