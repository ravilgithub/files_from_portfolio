<?php
	defined('_JEXEC') or die('(@)|(@)');
?>
<<?php echo $mTag; ?> class="my_rss_wrapper<?php echo $mClassSfx; ?>" style="width: <?php echo $mWidth; ?>px;">

	<script src="<?php echo JUri::base(true).'/modules/mod_my_rss_module/js/js_lib.js'; ?>"></script>
	
	<script type="text/javascript">
		jQuery(function(){
			if('<?php echo $toTop; ?>'){
				jQuery(window).scrollTop(191);
			}
			rssChannelCreateAndSelect('<?php echo json_encode($channels); ?>', '<?php echo $curChannelName; ?>', '<?php echo $rssPath; ?>');
		});
		function followingALink(link){
			window.open(link, '_blank');
		}
	</script>
	
<?php if($showtitle){ ?>			
	<<?php echo $hTag; ?> class="<?php echo $hClass; ?>"><?php echo $xmlData->channel->title; ?></<?php echo $hTag; ?>>
<?php } ?>

	<div class="my_rss_container">
		<form name="channelSelect" action="" method="">
<?php if($listNum == 1 or $listNum == 3){	?>
			<select style="<?php echo $topListPos; ?>" name="channel"></select>
<?php } ?>
			<div class="clear"></div>
<?php
		foreach($xmlData->channel->item as $item){
			$str = '<div class="rss_news" onclick="followingALink(\'' . $item->link . '\')"><h3>' . $item->title . '</h3>';
			$str .= '<p>' . $item->description . '</p>';
			echo $str .= '<span>' . substr($item->pubDate, 0, strrpos($item->pubDate, '+') -1) . '</span><div class="clear"></div></div>';
		}
		$head = '<div id="rss_footer"><a target="_blank" id="label" href="' . $xmlData->channel->image->link . '">';
		echo $head .= '<img src="' . $xmlData->channel->image->url . '" alt="' . $xmlData->channel->image->title . '" title="' . $xmlData->channel->description . '" /></a></div>';
?>
<?php if($listNum == 2 or $listNum == 3){	?>
			<select style="<?php echo $bottomListPos; ?>" name="channel"></select>
<?php } ?>
			<div class="clear"></div>
		</form>
	</div>
	
</<?php echo $mTag; ?>>