<?php
	defined('_JEXEC') or die('(@)|(@)');
	
	$mTag = trim(htmlspecialchars($params->get('module_tag')));
	$hTag = trim(htmlspecialchars($params->get('header_tag')));
	$mWidth = $params->get('mod_width', 600);
	$hClass = trim(htmlspecialchars($params->get('header_class')));
	$mClassSfx = htmlspecialchars($params->get('moduleclass_sfx'));
	$listNum = htmlspecialchars($params->get('list_num'));
	$topListPos = $params->get('top_list_pos') ? 'float: right;' : '';
	$bottomListPos = $params->get('bottom_list_pos') ? 'float: right;' : '';
	$showtitle = trim(htmlspecialchars($module->showtitle));
	
	$channels = array();
	$n = 0;
	$sufix = 1;
	
	$arr = explode(',', htmlspecialchars($params->get('channels')));
	
	foreach($arr as $channel){
		$channel = trim($channel);
	// результат примерно [0=>'auto', 1=>'rss']
		$chName = explode('.', substr($channel, strripos($channel, '/') +1));
		if(array_key_exists($chName[0], $channels)){
			$chName[0] .= "_$sufix";
			$sufix++;
		}
	// результат примерно [auto => ['авто' => 'http://news.yandex.ru/auto.rss']]
		$channels[$chName[0]] = explode('=', $channel);
	}
	
// значения по умолчанию ( первый RSS канал в админке )
	$curChannelArr = reset($channels);
	$curChannelName = key($channels);
	$curChannelLink = $curChannelArr[1];
	
	$rssPath = JUri::current();
	
	$jInput = JFactory::getApplication()->input;
	$get = $jInput->get->get('channel', NULL);
	
	$toTop = false;
	if($get){
		$curChannelLink = $channels[$get][1];
		$curChannelName = $get;
		$toTop = true;
	}
	
	$xmlData = simplexml_load_file("$curChannelLink");
	
?>