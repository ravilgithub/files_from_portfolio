<?php	
	defined('_JEXEC') or die('(@)|(@)');
	require_once dirname(__FILE__).'/helper.php';
	
	//$doc =& JFactory::getDocument();
	//$doc->addStyleSheet(JUri::base(true).'/modules/mod_my_rss_module/css/style.css');
	//$doc->addScript(JUri::base(true).'/modules/mod_my_rss_module/js/js_lib.js');
	
	//echo '<pre>';
	//print_r($module);
	//print_r($params);
	//print_r($doc);
	//echo '</pre>';
	
	require JModuleHelper::getLayoutPath('mod_my_rss_module', $params->get('layout', 'default'));
	
?>


